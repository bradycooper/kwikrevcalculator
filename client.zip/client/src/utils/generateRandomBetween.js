export const generateRandomBetween = (min, max) =>
    Math.floor(Math.random() * (max - min) + min);
  