export const generateRandomString = () =>
  (Math.random() + 1).toString(36).substring(9);
